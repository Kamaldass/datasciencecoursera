## File: liarsdice_init.R
## Author: John Rothfels (rothfels)
## Description: Liars Dice Initialization
## ---------------------------------------

GenerateComputer <- function(name, ndice = 5, type = "computer",
                             confidence = runif(1, min = .1, max = .3)) {
  ## This function generates a computer player with the specified attributes.
  ## You should add additional attributes as you see fit.
  return(list(name = name, ndice = ndice, type = type ,confidence = confidence))
}

## List of computer players, so computers[[1]] is the first computer player,
## computers[[1]]$name is the name of the first computer player, etc.
computers <- lapply(c("Don Knuth", "Alan Turing", "Mehran Sahami"),
                     GenerateComputer)

## All human players should be defined here. Right now, only one human is
## created.
humans <- list(list(name = "CS109L student", ndice = 5, type = "human"))

## You can modify gameplay by adding additional computer/human players, or by
## removing human players entirely. Pit your computers against each other
## and see how they perform!
players <- c(humans, computers)
