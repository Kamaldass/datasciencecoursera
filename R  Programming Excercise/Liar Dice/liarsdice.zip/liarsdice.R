## File: liarsdice.R
## Author: John Rothfels (rothfels)
## Description: Liars Dice
## ------------------------

source("liarsdice_init.R")
source("liarsdice_util.R")

## This is the main loop of the game. You should not need to change anything
## here, but feel free to check out the code or add anything else for your
## own functionality.
LiarsDice <- function(players, halt = TRUE, debug = FALSE) {
  ## Args:
  ##   halt - wait for carriage return between each player's turn
  ##   debug - print debugging information

  ndice <- sum(sapply(players, function(i) i$ndice))
  nplayers <- length(players)
  curr.player <- sample(1:nplayers, 1)   # current player

  bid <- list()                          # current bid
  bid.history <- list()                  # bid history
  dicepool <- sample(1:6, ndice, replace = TRUE)

  if (debug) {
    cat("\nDEBUG -- Here is the current pool of dice:\n")
    print(sort(dicepool))
  }

  ## Distribute dice to each player.
  count <- 0
  for (i in 1:nplayers) {
    players[[i]]$dice <- dicepool[(count + 1):(count + players[[i]]$ndice)]
    count <- count + players[[i]]$ndice
  }

  ## This loop continues for one round of play. It ends when somebody
  ## calls "liar", or (by default) when the highest bid is called.
  while(TRUE) {

    if (halt) {
      cat("\nEnter anything to continue:\n")
      scan(what = "raw", nlines = 1, quiet = TRUE)
    }

    ## Current player takes a turn.
    if (players[[curr.player]]$type == "computer") {
      bid <- ComputerTurn(players[[curr.player]], bid, ndice)
    } else {
      bid <- HumanTurn(players[[curr.player]], bid, ndice)
    }

    ## Update bid history.
    bid.history <- c(bid.history, list(bid))

    ## The round continues if the current player has not called "liar".
    if (is.null(bid$liar)) {
      ## Print the bid and continue.
      cat("\nBid:\n")
      print(bid)
      cat("\n\n")
      curr.player <- (curr.player %% nplayers) + 1
      next
    }

    ## If we get here, somebody has called "liar". We determine the
    ## loser and break out of the current loop.
    cat("\n", " ", " ", "Liar!\n\n\n")
    valid <- IsValid(dicepool, bid)

    if (valid) {
      cat("\nThe bid was valid.\n")
      ## The current player (i.e. the one who called "liar") is the loser.
      loser <- curr.player
    } else {
      cat("\nThe bid was invalid.\n")
      ## The person who made the previous call loses.
      if (curr.player == 1) {
        loser <- nplayers
      } else {
        loser <- curr.player - 1
      }
    }

    cat("\n", players[[loser]]$name, "loses.\n")

    cat("\nHere were the dice:\n")
    print(sort(dicepool))
    break
  }

  return(bid.history)
}

ComputerTurn <- function(computer, bid, ndice) {
  cat(paste("\n", computer$name, "'s turn:", sep = ""), "\n")

  if (length(bid) == 0) {

    ## -------------TODO----------------------------
    ## Decide how the computer will start the round.
    ## You should return a list with the following fields:
    ## 	 $face: a dice face value, 1 - 6
    ##	 $num: the number of dice named in the bid

    ## Right now, we unconditionally bid a single "1".
    bid <- list(face = 1, num = 1)
    return(bid)
  }

  ## If the highest bid has already been called, the computer must call
  ## "liar". Don't change this.
  if (bid$face == 6 && bid$num == ndice) {
    bid$liar <- TRUE
    return(bid)
  }

  ## --------------------------------TODO-----------------------------------
  ## Decide whether the computer will raise, and if so, how. As an initial
  ## idea, you may have the computer compute a "confidence" (it's up to you
  ## to decide how) that the current bid is a lie. If this confidence is greater
  ## than the computer$confidence value, the computer should raise.

  ## Right now, the computer unconditionally calls "liar".
  bid$liar <- TRUE
  return(bid)
}

## The rest of the code controls input from the player. You don't need to change
## anything here.

HumanTurn <- function(human, bid, ndice) {
  cat(paste("\n", human$name, "'s turn:", sep = ""), "\n")
  cat("\nHere is your hand:\n")
  print(sort(human$dice))
  cat("\nThe current bid is:\n")
  print(bid)
  cat("\nPlease make a new call:\n",
      "1. Ones\n", "2. Twos\n", "3. Threes\n", "4. Fours\n",
      "5. Fives\n", "6. Sixes\n", "7. Liar\n\n")

  choice <- NULL
  while(TRUE) {
    choice <- try(scan(what = integer(), nlines = 1, quiet = TRUE),
                  silent = TRUE)
    if (!IsLegalChoice(bid, choice, ndice)) {
      cat("\nIllegal choice. Please try again.\n")
      next
    }

    if (choice == 7) {
      bid$liar <- TRUE
      return(bid)
    }

    ## Have the user input values for their choice.
    bid <- GetValues(choice, bid, ndice)
    cat("\n\n")

    return(bid)
  }
}

GetValues <- function(category, bid, ndice) {
  if (length(bid) != 0 && category == bid$face) {
    temp <- bid                    # preserve current num for the category
  } else {
    temp <- list(face = category)  # allow any number
  }

  num <- NULL
  cat("\nChoose a number for the selected face value:\n")
  while(TRUE) {
    num <- try(scan(what = integer(), nlines = 1, quiet = TRUE),
               silent = TRUE)
    if (!IsLegalNum(num, temp$num, ndice)) {
      cat("\nIllegal choice. Please try again.\n")
      next
    }

    temp$num <- num
    return(temp)
  }
}
