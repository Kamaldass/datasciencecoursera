## File: chatterbot.R
## Author: <your name here>
## ------------------------

PatternMatch <- function(wildcard, pattern, target) {
  ## Function to perform pattern matching on two lists.
  ##
  ## Args:
  ##   wildcard - object which may match any sub-list.
  ##   pattern - list possibly containing wildcard elements.
  ##   target - list not containing wildcard elements.
  ## Returns:
  ##   The sub-list of target that matches the first occurrence of wildcard
  ##   in pattern, or NULL if the two lists do not match.

  ## <your code here>
}

PatternSubstitute <- function(wildcard, template, sub) {
  ## Function to replace each occurrence of wildcard in template with sub.
  ##
  ## Args:
  ##   wildcard - object to be treated as wildcard.
  ##   template - list possibly containing wildcard elements.
  ##   sub - object to substitute in place of wildcard elements.
  ## Returns:
  ##   Modified template.

  ## <your code here>
}


PatternTransform <- function(target, rule, aux = NULL, wildcard = "*") {
  ## Function to apply a chatterbot rule to a target list.
  ##
  ## Args:
  ##   target - list to match against rule's pattern.
  ##   rule - list containing pattern and templates.
  ##   aux - function to apply to the result of the pattern match *before*
  ##         the substitution is made. Do this only if aux is non-NULL.
  ##   wildcard - object which may match any sub-list.
  ## Returns:
  ##   A list of transformations, or NULL if target does not match
  ##   rule's pattern.

  ## <your code here>
}

Reflect <- function(target) {
  ## Function to reflect elements of target.
  ##
  ## Args:
  ##   target - list with words to reflect.
  ## Returns:
  ##   Modified target.

  ## <your code here>
}

## Main function which instantiates the chatterbot from the specified
## init file and begins the interactive loop.
RunChatterbot <- function(init.file = "./init_chatterbot.R") {
  source(init.file)
  while (TRUE) {
    ## Read question from console.
    question <- scan(what = character(0), nlines = 1, quiet = TRUE)
    if (length(question) == 0) {
      break;
    }
    ## Tokenize question into suitably formatted list.
    question <- as.vector(unlist(strsplit(question, " ")), mode = "list")

    for (i in 1:length(chatterbot)) {
      rule <- chatterbot[[i]]
      transforms <- PatternTransform(question, rule, aux = Reflect)
      if (is.null(transforms)) {
        next
      } else {
        answer <- transforms[[sample(1:length(transforms), 1)]]
        print(paste(unlist(answer), collapse = " "))
        break
      }
    }
  }
}
