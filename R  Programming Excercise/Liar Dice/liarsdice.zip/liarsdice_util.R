## File: liarsdice_util.R
## Author: John Rothfels (rothfels)
## Description: Utility Functions for Liars Poker
## ----------------------------------------------


## For a pool of dice, determines if the bid is valid.
## Returns "TRUE" or "FALSE".
IsValid <- function(dicepool, bid) {
  return(sum(dicepool == bid$face) >= bid$num)
}

## The remaining functions are used to determine the legality of player input.

## Determines if a legal category has been chosen based on the current bid.
IsLegalChoice <- function(bid, choice, ndice) {
  invalid <- (is.null(choice) || length(choice) != 1 || choice < 1 || choice > 7 ||
             (length(bid) != 0 && choice < bid$face) ||  # lower category than bid
             (length(bid) == 0 && choice == 7) ||        # liar before bids placed
             (length(bid) != 0 && bid$face == choice && CategoryMax(bid, ndice)))
  return(!invalid)
}

## Determines if the maximum bid has been made for a certain category.
CategoryMax <- function(bid, ndice) {
  return(bid$num == ndice)
}

## Determines if a legal number as been chosen based on the
IsLegalNum <- function(num, prev, ndice) {
  ## Args:
  ##   num - new num for the category
  ##   prev - previous value from the category (or NULL if non-existent)
  illegal <- (is.null(num) || length(num) != 1 || num < 1 || num > ndice ||
              (!is.null(prev) && num <= prev))
  return(!illegal)
}
